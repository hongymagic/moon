# Moon review evidence

The observations apply to commit f3873de3ece1cd423ceaad7b94f994d1b3975ca1 and release 2026.11.22-0. The results directory includes the Settings walkthroughs, the workspace rename and bar geometry probe, and the Windows x64 catalogue timings. Window titles in the walkthrough belong to the project's browser fixture.

## Reproducing the benchmark

Extract this archive to a new directory. From its benchmark directory, use Git, tar and patch to prepare a copy of the reviewed source. Set moon_repo to the path of a Moon checkout containing the release commit.

~~~sh
git -C "$moon_repo" archive f3873de3ece1cd423ceaad7b94f994d1b3975ca1 crates/moon-core | tar -x
patch -p1 < reuse-patterns.patch
~~~

The patch adds a switch to compare the current matcher with a fixed table of regexes for the fixture's configuration. Compilation and warm-up precede sampling. The probe checks equality of the serialised catalogues and alternates the two paths. A production implementation would need to rebuild its compiled rules when configuration changes.

On a Windows machine with the project's Rust and MSVC tools, build from the benchmark directory.

~~~powershell
cargo build --locked --release --target x86_64-pc-windows-msvc
.\target\x86_64-pc-windows-msvc\release\moon-ux-matcher-probe.exe
.\target\x86_64-pc-windows-msvc\release\workspace-probe.exe
~~~

The review used the repository's cargo-xwin toolchain in WSL to build the catalogue probe, then ran the executable on Windows. The workspace and bar probe was run with the portable core in WSL. Each probe creates its own in-memory windows. For native Arm64 measurement, use the aarch64-pc-windows-msvc target and run the resulting executable on Arm64 Windows.
