use moon_core::{
    command::Command,
    config::Config,
    desktop::{self, LayoutUndo},
    geometry::Rect,
    ids::{MonitorId, WindowId},
    world::{Event, Monitor, WindowInfo, World, reduce},
};
use std::{collections::BTreeMap, hint::black_box, time::Instant};
fn catalog(world: &World, births: &BTreeMap<WindowId, u64>) -> desktop::Catalog {
    desktop::catalog(
        black_box(world),
        black_box(births),
        "fixture".into(),
        false,
        LayoutUndo::default().status(world, false),
    )
}
fn time_us(world: &World, births: &BTreeMap<WindowId, u64>) -> f64 {
    let start = Instant::now();
    black_box(catalog(world, births));
    start.elapsed().as_secs_f64() * 1e6
}
fn main() {
    println!(
        "fixture platform={} {} ; 41 interleaved samples after 3 warmups",
        std::env::consts::OS,
        std::env::consts::ARCH
    );
    for n in [8u64, 50, 100] {
        let mut world = World::new(
            Config::default(),
            vec![Monitor {
                id: MonitorId(1),
                name: "Review".into(),
                bounds: Rect::new(0, 0, 3840, 2160),
                work_area: Rect::new(0, 0, 3840, 2120),
                scale: 1.25,
            }],
        )
        .unwrap();
        let mut births = BTreeMap::new();
        for id in 1..=n {
            let space = format!("{}", 1 + (id - 1) % 10);
            world = reduce(&world, Event::Command(Command::Workspace(space))).unwrap().world;
            world = reduce(
                &world,
                Event::WindowAdded(WindowInfo {
                    id: WindowId(id),
                    process_id: id as u32,
                    process: "ReviewEditor".into(),
                    class: "ReviewFixture".into(),
                    title: format!("Document {id}"),
                    rect: Rect::new(0, 0, 900, 600),
                    monitor: MonitorId(1),
                }),
            )
            .unwrap()
            .world;
            births.insert(WindowId(id), 1000 + id);
        }
        use moon_core::config::{review_mode, review_prepare};
        review_prepare(&world.config);
        review_mode(false);
        let original = catalog(&world, &births);
        review_mode(true);
        let control = catalog(&world, &births);
        assert_eq!(original.windows.len(), n as usize);
        assert_eq!(serde_json::to_vec(&original).unwrap(), serde_json::to_vec(&control).unwrap());
        for _ in 0..3 {
            black_box({
                review_mode(false);
                time_us(&world, &births)
            });
            black_box({
                review_mode(true);
                time_us(&world, &births)
            });
        }
        let mut defaults = Vec::new();
        let mut without = Vec::new();
        for i in 0..41 {
            if i % 2 == 0 {
                defaults.push({
                    review_mode(false);
                    time_us(&world, &births)
                });
                without.push({
                    review_mode(true);
                    time_us(&world, &births)
                });
            } else {
                without.push({
                    review_mode(true);
                    time_us(&world, &births)
                });
                defaults.push({
                    review_mode(false);
                    time_us(&world, &births)
                });
            }
        }
        defaults.sort_by(f64::total_cmp);
        without.sort_by(f64::total_cmp);
        println!(
            "windows={n}, equal_catalogs=true, default_p50_ms={:.3}, default_p95_ms={:.3}, reused_patterns_p50_ms={:.3}, reused_patterns_p95_ms={:.3}",
            defaults[20] / 1000.0,
            defaults[38] / 1000.0,
            without[20] / 1000.0,
            without[38] / 1000.0
        );
    }
}
